# CDPAudioRecorder录音与播放

### CDPAudioRecorder can recording,play sound file,and can convert to AMR file.Details see demo.

CDPAudioRecorder可以实现录音,播放音频,转码AMR,删除文件等各需求,详情看demo。

 ![image](https://github.com/cdpenggod/CDPAudioRecorder/blob/master/IMAGE.png)
