//
//  AppDelegate.h
//  AudioRecorder
//
//  Created by CDP on 2017/9/14.
//  Copyright © 2017年 CDP. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

